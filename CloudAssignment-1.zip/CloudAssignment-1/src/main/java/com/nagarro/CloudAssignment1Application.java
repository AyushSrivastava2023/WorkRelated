package com.nagarro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CloudAssignment1Application {

	public static void main(String[] args) {
		SpringApplication.run(CloudAssignment1Application.class, args);
	}

}
